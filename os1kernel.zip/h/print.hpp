//
// Created by os on 5/17/24.
//

#ifndef PROJEKAT_PRINT_HPP
#define PROJEKAT_PRINT_HPP

#include "../lib/hw.h"
#include "../lib/console.h"
#include "riscv.hpp"

extern void printString(char const* string);
extern void printInteger(uint64 integer);


#endif //PROJEKAT_PRINT_HPP
